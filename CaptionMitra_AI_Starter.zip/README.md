# CaptionMitra AI — starter project

A Next.js starter for a multilingual video subtitle SaaS. It includes:
- Responsive landing page and upload interface
- Hindi, Marathi, Hinglish and English output selection
- OpenAI Whisper transcription with segment timestamps
- AI translation of subtitle segments
- Editable subtitle lines
- SRT and TXT export
- Razorpay order creation and signature verification starter endpoints

## Important status
This is a working starter project, not a deployed production service. Real AI generation requires your API key. Razorpay endpoints are scaffolding only: before accepting customers, add authentication, subscription storage, webhook handling, abuse protection, refund/cancellation handling and test the full payment lifecycle. The MP4 caption burn-in/export feature is not included in this first version; it is a planned next phase.

## Requirements
- Node.js 20+
- OpenAI API key with billing/usage enabled for transcription and translation
- Optional Razorpay account and API keys (start in Test Mode; KYC is required before live payments)

## Run locally
1. Install Node.js 20 or newer.
2. Extract this ZIP and open the folder in Terminal / Command Prompt.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local`.
5. Add your `OPENAI_API_KEY` to `.env.local`.
6. Run `npm run dev`.
7. Open http://localhost:3000.

Without an API key the website UI runs, but Generate captions returns a setup message. API keys must stay on the server and must never be placed in frontend code or shared in chat.

## Deploy
Deploy to Vercel or another Node.js host. Add the environment variables in the host dashboard. Note that serverless request size/time limits may require a direct-to-object-storage, chunked upload pipeline for longer videos. Do not promise unlimited video length on the starter architecture.

## Before launch checklist
- [ ] Add Supabase Auth and database tables for users, jobs, usage and subscriptions.
- [ ] Add private object storage and signed upload URLs.
- [ ] Add chunked audio extraction / long-video handling.
- [ ] Add FFmpeg-based MP4 caption burn-in worker.
- [ ] Add Razorpay webhook verification and subscription lifecycle.
- [ ] Add rate limits, file validation, malware scanning and cost limits.
- [ ] Add privacy policy, terms, refund policy and contact details.
- [ ] Test Hindi/Marathi transcription quality with native speakers.
- [ ] Complete Razorpay KYC and switch to live keys only after successful test payments.

## Suggested initial pricing (not activated)
Free: limited trial minutes.
Creator: ₹199/month — higher monthly minutes and SRT/VTT/TXT export.
Studio: ₹499/month — larger limits and MP4 caption export when that feature is implemented.
These are draft prices only; validate AI costs before publishing plans.
