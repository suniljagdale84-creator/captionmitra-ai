 "use client";

import { useMemo, useState } from "react";
import { UploadCloud, Languages, Download, Sparkles, Captions, FileVideo, CheckCircle2, Loader2, Copy } from "lucide-react";

type Cue = { start: number; end: number; text: string };
const languages = [
  { id: "hi", label: "Hindi", native: "हिंदी" },
  { id: "mr", label: "Marathi", native: "मराठी" },
  { id: "hinglish", label: "Hinglish", native: "Roman Hindi" },
  { id: "en", label: "English", native: "English" }
];

function stamp(seconds: number) {
  const ms = Math.max(0, Math.round(seconds * 1000));
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000), milli = ms % 1000;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")},${String(milli).padStart(3,"0")}`;
}
function toSrt(cues: Cue[]) {
  return cues.map((c,i) => `${i+1}\n${stamp(c.start)} --> ${stamp(c.end)}\n${c.text}`).join("\n\n");
}

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [language, setLanguage] = useState("hi");
  const [cues, setCues] = useState<Cue[]>([]);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [rawText, setRawText] = useState("");
  const srt = useMemo(() => toSrt(cues), [cues]);

  async function generate() {
    if (!file) return;
    setBusy(true); setError(""); setStatus("Uploading video and extracting audio…"); setCues([]);
    try {
      const data = new FormData(); data.append("file", file); data.append("language", language);
      setStatus("AI is transcribing and translating…");
      const response = await fetch("/api/captions", { method: "POST", body: data });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Caption generation failed.");
      setCues(result.cues || []); setRawText(result.transcript || "");
      setStatus("Your captions are ready.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
      setStatus("");
    } finally { setBusy(false); }
  }

  function download(name: string, content: string, type = "text/plain") {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = name; a.click(); URL.revokeObjectURL(url);
  }

  function updateCue(index: number, text: string) {
    setCues(prev => prev.map((c,i) => i === index ? {...c, text} : c));
  }

  return <main className="shell">
    <nav className="nav">
      <a className="brand" href="#"><span className="brandIcon"><Captions size={21}/></span>CaptionMitra <b>AI</b></a>
      <span className="navTag">VIDEO SUBTITLE STUDIO</span>
      <a className="navLink" href="#how">How it works</a>
    </nav>

    <section className="hero">
      <div className="eyebrow"><Sparkles size={14}/> YOUR MULTILINGUAL VIDEO ASSISTANT</div>
      <h1>Every video deserves<br/><span>the right words.</span></h1>
      <p>Turn your video into accurate subtitles in Hindi, Marathi, Hinglish or English. Edit them, then download your SRT file.</p>
    </section>

    <section className="workspace">
      <div className="panel">
        <div className="panelHead"><div><span className="step">01</span><h2>Upload your video</h2></div><span className="muted">MP4, MOV, WEBM</span></div>
        <label className={`dropzone ${file ? "hasFile" : ""}`}>
          <input type="file" accept="video/mp4,video/quicktime,video/webm,audio/mpeg,audio/wav,audio/mp4" onChange={e => {setFile(e.target.files?.[0] || null); setCues([]); setError(""); setStatus("");}}/>
          {file ? <><FileVideo size={34}/><strong>{file.name}</strong><small>{(file.size/1024/1024).toFixed(1)} MB · Ready to process</small></> :
          <><span className="uploadCircle"><UploadCloud size={26}/></span><strong>Drop your video here</strong><small>or click to browse your device</small><em>For this starter version, keep files under 25 MB.</em></>}
        </label>

        <div className="fieldLabel"><Languages size={17}/> Choose output language</div>
        <div className="languageGrid">
          {languages.map(l => <button key={l.id} onClick={() => setLanguage(l.id)} className={`language ${language===l.id?"selected":""}`}><span>{l.native}</span><small>{l.label}</small>{language===l.id && <CheckCircle2 size={16}/>}</button>)}
        </div>
        <button className="primary" disabled={!file || busy} onClick={generate}>{busy ? <><Loader2 className="spin" size={18}/> Generating captions…</> : <><Sparkles size={18}/> Generate captions</>}</button>
        <p className="privacy">Your file is sent to the configured AI service for processing. Do not upload confidential videos.</p>
        {status && <div className="status"><Loader2 size={15} className={busy?"spin":""}/>{status}</div>}
        {error && <div className="error">{error}</div>}
      </div>

      <div className="panel resultPanel">
        <div className="panelHead"><div><span className="step">02</span><h2>Your captions</h2></div><span className="muted">{cues.length ? `${cues.length} subtitle lines` : "PREVIEW"}</span></div>
        {cues.length ? <>
          <div className="resultTools"><span><CheckCircle2 size={15}/> Generated · Editable</span><button onClick={() => download("captions.srt",srt,"text/srt")}><Download size={15}/> Download SRT</button></div>
          <div className="cueList">{cues.map((c,i)=><div className="cue" key={i}><div className="cueTime">{stamp(c.start)} → {stamp(c.end)}</div><textarea value={c.text} onChange={e=>updateCue(i,e.target.value)} aria-label={`Subtitle line ${i+1}`}/></div>)}</div>
          <div className="bottomActions"><button className="secondary" onClick={() => download("captions.txt",cues.map(c=>c.text).join("\n"),"text/plain")}><Download size={15}/> Download TXT</button><button className="secondary" onClick={() => navigator.clipboard.writeText(srt)}><Copy size={15}/> Copy SRT</button></div>
        </> : <div className="empty">
          <div className="previewBox"><span className="previewPill">CAPTION PREVIEW</span><div className="fakeCaption">आपकी कहानी,<br/><b>आपकी भाषा में।</b></div><small>Your subtitles will appear here</small></div>
          <div className="emptyHint"><Sparkles size={17}/><span>Upload a video and choose a language to create your first captions.</span></div>
        </div>}
      </div>
    </section>

    <section className="how" id="how"><div className="eyebrow">SIMPLE BY DESIGN</div><h2>From video to subtitles in 3 steps</h2><div className="steps">
      <div><span>1</span><h3>Upload</h3><p>Select a video or audio file from your device.</p></div>
      <div><span>2</span><h3>Choose language</h3><p>Generate Hindi, Marathi, Hinglish or English subtitles.</p></div>
      <div><span>3</span><h3>Edit & download</h3><p>Correct the text and export an SRT or TXT file.</p></div>
    </div></section>
    <footer><a className="brand" href="#"><span className="brandIcon"><Captions size={18}/></span>CaptionMitra <b>AI</b></a><span>Made for creators · Starter edition</span></footer>
  </main>;
}