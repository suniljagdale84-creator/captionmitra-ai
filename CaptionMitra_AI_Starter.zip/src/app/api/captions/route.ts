import OpenAI from "openai";
import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

const languageNames: Record<string,string> = {
  hi: "Hindi in Devanagari script",
  mr: "Marathi in Devanagari script",
  hinglish: "Hinglish (Hindi written in Roman letters, natural conversational style)",
  en: "English"
};

export async function POST(req: NextRequest) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({error:"AI is not connected yet. Add OPENAI_API_KEY in .env.local (see README) to enable real caption generation."},{status:503});
    }
    const form = await req.formData();
    const file = form.get("file");
    const language = String(form.get("language") || "hi");
    if (!(file instanceof File)) return NextResponse.json({error:"Please upload a video or audio file."},{status:400});
    if (file.size > 25 * 1024 * 1024) return NextResponse.json({error:"This starter version supports files up to 25 MB. Larger videos need a chunked upload pipeline."},{status:413});
    if (!languageNames[language]) return NextResponse.json({error:"Unsupported language."},{status:400});

    const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const audioFile = new File([await file.arrayBuffer()], file.name.replace(/\.[^.]+$/, ".mp3"), {type:"audio/mpeg"});
    const transcription = await client.audio.transcriptions.create({
      file: audioFile,
      model: "whisper-1",
      response_format: "verbose_json",
      timestamp_granularities: ["segment"]
    } as any);

    const segments = (transcription as any).segments || [];
    const sourceText = segments.map((s:any)=>s.text).join(" ").trim();
    if (!sourceText) return NextResponse.json({error:"No speech was detected. Try a clearer audio/video file."},{status:422});

    const translated = await client.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.2,
      response_format: {type:"json_object"},
      messages: [
        {role:"system",content:`You translate subtitle segments into ${languageNames[language]}. Preserve meaning, names, numbers and tone. Keep each segment concise and suitable for on-screen subtitles. Return ONLY JSON with shape {"translations":["..."]} and exactly the same number of items as the input segments.`},
        {role:"user",content:JSON.stringify(segments.map((s:any)=>s.text))}
      ]
    });
    const parsed = JSON.parse(translated.choices[0]?.message?.content || '{"translations":[]}');
    const translations: string[] = parsed.translations || [];
    const cues = segments.map((s:any,i:number)=>({
      start:Number(s.start)||0,
      end:Number(s.end)||((Number(s.start)||0)+2),
      text:String(translations[i] ?? s.text).trim()
    }));
    return NextResponse.json({cues, transcript:sourceText});
  } catch (e:any) {
    console.error("caption generation error", e);
    return NextResponse.json({error:e?.message || "Caption generation failed. Please try again."},{status:500});
  }
}