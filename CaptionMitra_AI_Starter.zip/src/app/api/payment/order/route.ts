import Razorpay from "razorpay";
import { NextResponse } from "next/server";

export async function POST() {
  const key_id = process.env.RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;
  if (!key_id || !key_secret) return NextResponse.json({error:"Razorpay is not configured. Add your test/live keys after completing account setup."},{status:503});
  try {
    const razorpay = new Razorpay({key_id,key_secret});
    const order = await razorpay.orders.create({amount:19900,currency:"INR",receipt:`cm_${Date.now()}`});
    return NextResponse.json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:key_id});
  } catch {
    return NextResponse.json({error:"Could not create payment order."},{status:500});
  }
}