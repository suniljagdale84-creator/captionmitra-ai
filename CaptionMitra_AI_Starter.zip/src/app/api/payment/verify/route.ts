import crypto from "crypto";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!secret) return NextResponse.json({error:"Payment gateway is not configured."},{status:503});
  const body = await req.json();
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature} = body;
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) return NextResponse.json({error:"Missing payment verification fields."},{status:400});
  const expected = crypto.createHmac("sha256",secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
  const a = Buffer.from(expected), b = Buffer.from(String(razorpay_signature));
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return NextResponse.json({verified:false,error:"Payment signature did not match."},{status:400});
  // TODO: Store the verified subscription in Supabase against the authenticated user.
  return NextResponse.json({verified:true,message:"Payment signature verified. Subscription persistence must be enabled before accepting live customers."});
}