import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CaptionMitra AI — Video captions made simple",
  description: "Create Hindi, Marathi, Hinglish and English subtitles for your videos."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}